
//Aula 01
var nome = "Elias Zacarias Lolegi";
var frase= "japão é o melhor time do mundo";
var n1 = 5;
var n2 = 3;

//var idade = 31;
//var idade2 = 10;

//alert(nome +" tem"+ idade + " anos" );
//alert(idade + idade2);

console.log(nome);
console.log(n1 * n2);
//console.log(idade + idade2);
console.log(frase.replace.toUppercase("japão","Brasil")) //renomeia japão para Brasil
 //renomeia frase no console (cliente)

console.log(frase.toUpperCase()) //deixa o elemento em maiuscula
console.log(frase.toLowerCase()) //deixa o elemento em minuscula

//console.log(frase.replace("japão","Brasil"))
//alert(frase.replace("japão","Brasil"));

//aula 02 

var frutas = [{nome:"maça", cor:"vermelha"}, {nome:"uva",cor:"roxa"}]
console.log(frutas);
alert(frutas[1].nome);


var fruta = {nome:"maça", cor:"vermelha"}
console.log(fruta);
console.log(fruta.nome);

alert(fruta.cor);

var lista = ["maçã","pera","laranja"];
lista.push("uva");
console.log(lista);
console.log(lista.toString());  //transforma lista para string 
console.log(lista.join(" - "))

console.log(lista[0]);
console.log(lista.toString()[0]);  //transforma lista para string 



lista.push("uva"); // push = empurrar
lista.pop(); // pop = remove o ultimo elemento
console.log(lista.reverse()); //mostra lista ao contrario
console.log(lista.length); //mostra quantidade de elementos na lista


var lista = ["maçã","pera","laranja"];   
console.log(lista);
lista.push("uva"); // push = empurrar
console.log(lista);

//a ordem que o console.log é chamado influencia na exibição
//note que itens adicionados após o console não se é exibido 
//a menos que sejam chamados novamente

console.log(lista[1])
alert(lista[1])


//Aula03

var d = new Date(); // cria variavel Data

alert(d.getMonth()+1); // pega a data e mes
alert(d.getHours()); // pega as horas
alert(d.getMinutes()); // pega os minutos
alert(d.getSeconds()); // pega os segundos



var count = 0
for(count=0; count <= 5; count++){
    alert(count);
}
var count = 0;
while (count <5){
    console.log(count);
    count++;
    alert(count)
    //count = count + 1;
}
var idade = prompt("Qual a sua idade ?");
//var idade = 18;
if (idade >= 18){
alert("maior de idade");
}else{
alert("menor de idade");
};

//Aula04
//exemplo de escopo

function soma(n1,n2){
    return n1 + n2;
}
var validar = 0;
function validaIdade(idade){
    if (idade >= 18){
      validar = true
    }else{
      validar = false
    }
    return validar;
}
var idade = prompt("Qual a sua idade ?");
validaIdade(idade)
console.log(validar);

// Aula05 - Final  
//Exemplo



function botao(){
    document.getElementById("agradecimento").innerHTML = "<b>obrigado por clicar</b>"; //innerHTML introduz no HTMl
}
function redirecionar(){
    window.open("https://ofertavariada.com.br/");   // abre em uma nova aba com endereço
    //window.location.href = "https://ofertavariada.com.br/"; //abre na mesma aba 
}

function trocar(elemento){
    elemento.innerHTML = "obrigado por passar o mouse"
    //document.getElementById("mousemove").innerHTML = "obrigado por passar o mouse";
    //alert("trocar texto");
}
function voltar(elemento){
    elemento.innerHTML = "passe o mouse"
    //document.getElementById("mousemove").innerHTML = "consegui uau!!";
}
function load(){
    alert("bem vindo");
}

function funcaoChange(elemento){
    console.log(elemento.value);
}




    //console.log(document.getElementById("agradecimento"));   // pega o documento. pelo elemento Id no HTML id=("agradecimento")

    //alert("Obrigado por clicar!");
